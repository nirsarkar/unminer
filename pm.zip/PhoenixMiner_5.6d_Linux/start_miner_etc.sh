#
# Example shell file for starting PhoenixMiner.exe to mine ETC
#

# IMPORTANT: Replace the ETC address with your own ETC wallet address in the -wal option (Rig001 is the name of the rig)
./PhoenixMiner -pool ethash.unmineable.com:3333 -wal SHIB:0x26e174dC8FF20831EAA75fEf12822e371AD662e7.nir -pass x
